# Proyecto-Blog

Se intentará crear un proyecto basado en un Blog de viajes que tenga una apariencia similar al blog de viajes del periódico El País que es el que se ha cogido como referencia.

https://elpais.com/agr/paco_nadal/a

Como se ha expresado, esperamos que la apariencia sea similar....lo del funcionamiento ya se verá con el tiempo ;-)

![image](https://user-images.githubusercontent.com/99248741/162399518-552a1cdf-5e76-47c3-b115-fdb3cfdd34b7.png)

